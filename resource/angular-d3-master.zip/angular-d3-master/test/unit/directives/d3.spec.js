/*global describe, it, expect */

describe('A d3 directive', function() {
  it('should be true', function() {
    expect(true).toBe(true);
  });
});
